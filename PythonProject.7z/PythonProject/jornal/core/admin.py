

# Register your models here.
from django.contrib import admin
from .models import Categoria, Noticia, Comentario

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome')
    search_fields = ('nome',)

@admin.register(Noticia)
class NoticiaAdmin(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'autor', 'categoria', 'publicada_em')
    list_filter = ('categoria', 'publicada_em')
    search_fields = ('titulo', 'corpo')

@admin.register(Comentario)
class ComentarioAdmin(admin.ModelAdmin):
    list_display = ('id', 'usuario', 'noticia', 'criado_em')
    list_filter = ('criado_em',)
    search_fields = ('corpo',)
